Number = int(input("Enter n (>=2): "))

Fibonaccis = [1,1]
n = 0

for i in range(Number-2):
	Fibonaccis.append(Fibonaccis[n]+Fibonaccis[n+1])
	n=n+1

print(Fibonaccis)

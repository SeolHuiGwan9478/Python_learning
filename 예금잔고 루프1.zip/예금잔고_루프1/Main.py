Initial_balance = int(input("Initial balance? \n")) #원금을 정수 타입으로 입력 받는다.
Initial_rate = int(input("Annual interest rate in percent? \n")) #이자율을 정수 타입으로 입력 받는다.
years = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20] #20년 후 이므로 List years에 1~20까지 작성

for year in years: #for 반복문, year 은 변수
	S = Initial_balance*(1+Initial_rate/100)**year #years List에 20까지 있으므로 20번 반복, 최종 예금잔고 구하는 S 변수 지정
print("In case initial balance is {:.2f}\nand annual interest rate is {:.2f} percent,\nfinal balance after 20 years will be {:.2f}".format(Initial_balance,Initial_rate,S)) #method format을 이용하여 실수는 소수점 이하 2자리까지 출력
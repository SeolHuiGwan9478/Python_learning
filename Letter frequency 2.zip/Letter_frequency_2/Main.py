import string

f = open('data/hamlet.txt', 'r')
text = f.read()
text = text.lower()

alphabets = list(string.ascii_lowercase)  

alphabet_total = 0
for alphabet in alphabets:
	alphabet_total = alphabet_total + text.count(alphabet)
	
print("Letter Frequency in frequency order")
print("+----------+")
print("| C | freq |")
print("+----------+")

alphabet_frequencyS = []
alphabet_frequencyO = []
for alphabet1 in alphabets:
	alphabet_frequency = text.count(alphabet1) * 100 / alphabet_total
	alphabet_frequencyS.append(alphabet_frequency)
	alphabet_frequencyO.append(alphabet_frequency)
	
sort = sorted(alphabet_frequencyS, reverse=True)

for i,x in enumerate(sort):
	alphabet_sort = alphabets[alphabet_frequencyO.index(x)]
	print("| %s |  %.2f|" % (alphabet_sort, sort[i]))
print("+----------+")

'''
x = alphabets[alphabet_frequencyO.index(sort[0])]
print("| %s | %.2f|" % (x, sort[0]))
del sort[0]
'''


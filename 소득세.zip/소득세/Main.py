income = int(input("Please enter your income: \n"))

RATE1 = 0.06
RATE2 = 0.15
RATE3 = 0.24
RATE4 = 0.35
RATE5 = 0.38
STANDARD1 = 12000000
STANDARD2 = 46000000
STANDARD3 = 88000000
STANDARD4 = 300000000

if income <= STANDARD1:
	tax = income * RATE1
	print("Your tax is {:.2f}".format(tax))
elif income <= STANDARD2:
	tax = ((income - STANDARD1) * RATE2) + (STANDARD1 * RATE1)
	print("Your tax is {:.2f}".format(tax))
elif income <= STANDARD3:
	tax = ((income - STANDARD2) * RATE3) + ((STANDARD2-STANDARD1) * RATE2) + (STANDARD1 * RATE1)
	print("Your tax is {:.2f}".format(tax))
elif income <= STANDARD4:
	tax = ((income - STANDARD3) * RATE4) + ((STANDARD3-STANDARD2) * RATE3) + (STANDARD1 * RATE1) + ((STANDARD2-STANDARD1) * RATE2)
	print("Your tax is {:.2f}".format(tax))
else:
	tax = ((income - STANDARD4) * RATE5) + ((STANDARD4-STANDARD3) * RATE4) + (STANDARD1 * RATE1) + ((STANDARD2-STANDARD1) * RATE2) + ((STANDARD3-STANDARD2) * RATE3)
	print("Your tax is {:.2f}".format(tax))

	
	
inputs = input("Enter int numbers separated by space ")
numbers = [int(num) for num in inputs.split()]

# 이제 numbers는 int의 리스트이다.

# FILL OUT
answer = [] 
n = 0
for i in range(len(numbers)):
	answer.append(numbers[n-1])
	n = n - 1
print(answer)
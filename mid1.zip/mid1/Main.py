n = int(input('Enter a positive number: '))

# FILL OUT
answer = 0
for i in range(1,n+1):
	answer = answer + i
	
print(answer)
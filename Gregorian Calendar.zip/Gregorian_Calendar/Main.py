# To compute the week day, given year, month, day.
# The day after the 4th. October 1582 would be 15th. October 1582
year = int(input('Enter Gregorian year (year >= 1583): \n'))
month = int(input('Enter Gregorian month (month: 1..12): \n'))
day = int(input('Enter Gregorian day (1..28|29|30|31): \n'))

y = year
d = day
m = month

if month in [1, 3, 5, 7, 8, 10, 12]:
	month_days = 31
elif month in [4, 6, 9, 11]:
	month_days = 30

if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
	if month == 2:
		month_days = 29
else:
	if month == 2:
		month_days = 28

y += 8000
if m < 3:	
  y -= 1
  m += 12
julian = (y*365) + (y//4) - (y//100) + (y//400) - 1200820 + (m*153+3)//5 - 92 + (d-1)

if year < 1583:
	print("Enter year >= 1583! Try again!")
if year >= 1583:
	if month > 12:
		print("Wrong month! Try again!")
if 1 <= month <= 12:
	if day > month_days:
		print("Wrong day! Try again!")

if year >= 1583 and month <= 12 and day <= month_days:
	if julian % 7 == 0:
		day_week = "Monday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))
	elif julian % 7 == 1:
		day_week = "Tuesday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))
	elif julian % 7 == 2:
		day_week = "Wednesday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))
	elif julian % 7 == 3:
		day_week = "Thursday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))
	elif julian % 7 == 4:
		day_week = "Friday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))
	elif julian % 7 == 5:
		day_week = "Saturday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))
	elif julian % 7 == 6:
		day_week = "Sunday"
		print("%d-%d-%d is %s" %(year,month,day,day_week))


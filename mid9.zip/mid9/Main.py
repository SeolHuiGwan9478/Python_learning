n = int(input('Enter a positive number: '))

# FILL OUT
son = list(range(1,n+1))

t = 0
for i in range(1,n+1):
	print(son[-i: ])
	
	
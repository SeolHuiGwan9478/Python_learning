f = open('data/hamlet.txt', 'r')
text = f.read()
text = text.lower()

alphabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
alphabet_total = 0
for alphabet in alphabets:
	alphabet_total = alphabet_total + text.count(alphabet)
	
print("Letter Frequency in alphabet order")
print("+----------+")
print("| C | freq |")
print("+----------+")

for alphabet1 in alphabets:
	alphabet_frequency = text.count(alphabet1) * 100 / alphabet_total
	print("| %s |  %.2f|" % (alphabet1, alphabet_frequency))
	
print("+----------+")


	



'''
alphabets2 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
alphabet_total1 = 0
alphabet_total2 = 0

for alphabet1 in alphabets1:
	alphabet_total1 = alphabet_total1 + text.count(alphabet1)
for alphabet2 in alphabets2:
	alphabet_total2 = alphabet_total2 + text.count(alphabet2)
	
alphabet_total3 = alphabet_total1 + alphabet_total2


print("Letter Frequency in alphabet order")
print("+----------+")
print("| C | freq |")
print("+----------+")

alphabet_number1 = []
alphabet_number2 = []

for alphabet1 in alphabets1:
	x = text.count(alphabet1)
	alphabet_number1.append(x)
for alphabet2 in alphabets2:
	y = text.count(alphabet2)
	alphabet_number2.append(y)
	
alphabet_number3 = [int(alphabet_number1[i] + alphabet_number2[i]) for i in range(len(alphabet1))]


for i, alphabet_number in enumerate(alphabet_number3):
	alphabet_frequency = (alphabet_number/alphabet_total3)/100
	print("| %s |  %.2f|" % (alphabets1[i], alphabet_frequency)) 
'''
	
	

		
	

	

	

 


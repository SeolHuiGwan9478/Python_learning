inputs = input("Enter int numbers separated by space ")
numbers = [int(num) for num in inputs.split()]

# 이제 numbers는 int의 리스트이다.

# FILL OUT
x = numbers[-1]
n = 1
for i in range(len(numbers)-1):
	numbers[-n] = numbers[-n-1]
	n = n + 1
numbers[0] = x	
print(numbers)


inputs = input("Enter int numbers separated by space ")
numbers = [int(num) for num in inputs.split()]

# 이제 numbers는 int의 리스트이다.

# FILL OUT
for i in range(len(numbers)//2):
	son = numbers.pop(2*i+1) + 1
	numbers.insert(2*i+1, son)
	

print(numbers)
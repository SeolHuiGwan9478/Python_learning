year = int(input("Enter Gregorian year (year >= 1583): \n\n"))
months1 = ['January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
months2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]


for i in months2:
	print("%s %d" %(months1[i-1],year))
	print('  S  M  T  W  T  F  S')
	month = i
	if month in [1, 3, 5, 7, 8, 10, 12]:
		month_days = 31
	else:
		if month in [4, 6, 9, 11]:
 			month_days = 30
	if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
		if month == 2:
			month_days = 29
	else:
		if month == 2:
			month_days = 28
	m = month
	y = year
	d = 1
	y += 8000
	if m < 3:
		y -= 1
		m += 12
	julian = (y*365) + (y//4) - (y//100) + (y//400) - 1200820 + (m*153+3)//5 - 92 + (d-1)
	
	start_day = julian % 7
	
	if (0 <= start_day <= 5):
		for b in range(start_day + 1):
			print("   ",end='')
		
	for z in range(1, month_days + 1):
		if (0 <= start_day <= 5):             
			if (start_day + z + 1) % 7 == 0:
				print("{:3d}".format(z))
			elif z == month_days:
				print("{:3d}\n".format(z))
			else:
				print("{:3d}".format(z),end='')
		else:                                
			if z % 7 == 0:
				print("{:3d}".format(z))
			elif z == month_days:
				print("{:3d}\n".format(z))	
			else:
				print("{:3d}".format(z),end='')
			

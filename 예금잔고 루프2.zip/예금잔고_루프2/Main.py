initial_balance = int(input("Initial balance? \n")) #원금을 정수 타입으로 입력 받는다.
interest_rate = int(input("Annual interest rate in percent? \n")) #이자율을 정수 타입으로 입력 받는다.
years = int(input("How many years (year >= 0) ? \n")) #몇년 후 예금잔고를 확인하려는지 년수를 입력 받는다.

for year in range(1,years+1): #range(1,years+1)는 1부터 입력받은 n 까지 있는 List와 같다. for문을 통해 n번 반복한다
	final_balance = initial_balance*(1+(interest_rate/100))**year #n년 후 총 예금 잔고 구하는 변수 지정

print("In case initial balance is {:.2f}".format(initial_balance)) #format method를 이용하여 소수점이하 2자리까지 원금 출력
print("and annual interest rate is {:.2f} percent,".format(interest_rate)) #format method를 이용하여 소수점이하 2자리까지 이자율 출력
print("final balance after {:d} years will be {:.2f}".format(years,final_balance)) #format method를 이용하여 소수점이하 2자리까지 n년후 예금 잔고 출력

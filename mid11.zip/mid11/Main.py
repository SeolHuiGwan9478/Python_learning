n = int(input('Enter a positive number: '))

# FILL OUT
answer = 1
for i in range(n-1):
	answer = 2 * answer + 1
	
	
print(answer)
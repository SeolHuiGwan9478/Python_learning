inputs = input("Enter int numbers separated by space ")
numbers = [int(num) for num in inputs.split()]

# 이제 numbers는 int의 리스트이다.

# FILL OUT
answer = sorted(numbers)[(len(numbers)-1)//2]

print(answer)